#!/usr/bin/env python3
"""
Integration Layer: Prawo Zero (Phases 1-5) ↔ L7 Bridge (VPS)
=============================================================
Author:  Zbigniew-Diakon-001 / Angel Guardian Tech AI
Version: 1.0.0
Date:    2026-03-08

Bridges two separate stacks:
  LEFT  — Prawo Zero (Ethereum/IPFS, phases 1-5)
            FastAPI backend, PrawoZeroGuard.sol, CircuitBreaker,
            MonitoringMetrics, IncidentManager
  RIGHT — L7 Bridge VPS (Solana / Java Spring Boot)
            Memory5 API :8080, Layer4 FastAPI :8001,
            AutoGen crisis agents, Telegram Bot, Chroma :8000

Integration points:
  1. CircuitBreaker state → L7 crisis agents (emergency sync)
  2. CNOTA events (Layer4) → Prawo Zero metrics pipeline
  3. Prawo Zero violations → Memory5 API (vector store + audit)
  4. Moltbook beacon → IncidentManager postmortem feed
  5. Virtue Passport score → PrawoZeroGuard compliance check
"""

import os
import asyncio
import logging
import httpx
import json
from datetime import datetime, timezone
from dataclasses import dataclass, asdict, field
from typing import Optional, Dict, List, Any
from enum import Enum

# ── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
)
log = logging.getLogger("l7_integration")

# ── Config ───────────────────────────────────────────────────────────────────

# L7 Bridge VPS endpoints (set in .env)
MEMORY5_URL     = os.getenv("MEMORY5_URL",  "http://localhost:8080")
LAYER4_URL      = os.getenv("LAYER4_URL",   "http://localhost:8001")
CHROMA_URL      = os.getenv("CHROMA_URL",   "http://localhost:8000")
MOLTBOOK_KEY    = os.getenv("MOLTBOOK_API_KEY", "")
MOLTBOOK_BASE   = "https://www.moltbook.com/api/v1"

# Prawo Zero endpoints
PRAWO_ZERO_URL  = os.getenv("PRAWO_ZERO_URL", "http://localhost:8000")

# Integration secrets
INTEGRATION_SECRET = os.getenv("INTEGRATION_SECRET", "changeme")

# Timeouts
HTTP_TIMEOUT = httpx.Timeout(10.0, connect=5.0)

# ── Enums ────────────────────────────────────────────────────────────────────

class SyncDirection(str, Enum):
    PRAWO_TO_L7   = "prawo_zero → l7_bridge"
    L7_TO_PRAWO   = "l7_bridge → prawo_zero"
    BIDIRECTIONAL = "bidirectional"

class IntegrationEvent(str, Enum):
    CIRCUIT_OPEN         = "circuit_breaker_opened"
    CIRCUIT_CLOSED       = "circuit_breaker_closed"
    EMERGENCY_DETECTED   = "emergency_detected"
    CNOTA_EARNED         = "cnota_earned"
    CNOTA_SLASHED        = "cnota_slashed"
    VIRTUE_SCORE_UPDATE  = "virtue_score_updated"
    VIOLATION_RECORDED   = "violation_recorded"
    INCIDENT_CREATED     = "incident_created"
    RECOVERY_COMPLETED   = "recovery_completed"
    MOLTBOOK_POST        = "moltbook_post"

# ── Data models ───────────────────────────────────────────────────────────────

@dataclass
class IntegrationPayload:
    event_type:  IntegrationEvent
    source:      str
    target:      str
    agent_id:    str
    data:        Dict[str, Any]
    timestamp:   str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    signature:   Optional[str] = None

    def to_json(self) -> str:
        return json.dumps(asdict(self))

@dataclass
class CnotaEvent:
    actor_id:    str
    action_code: str
    cp_delta:    int
    new_score:   float
    tier:        str
    timestamp:   str

@dataclass
class CircuitBreakerState:
    is_open:          bool
    failure_count:    int
    success_count:    int
    last_state_change: str
    affected_systems: List[str]

@dataclass
class VirtuePassportSnapshot:
    actor_id:     str
    wisdom:       float
    justice:      float
    courage:      float
    temperance:   float
    overall:      float
    tier:         str
    on_chain_hash: Optional[str] = None

# ── HTTP helpers ──────────────────────────────────────────────────────────────

async def _get(url: str, path: str, params: dict = None) -> Optional[Dict]:
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            r = await client.get(f"{url}{path}", params=params)
            r.raise_for_status()
            return r.json()
    except Exception as e:
        log.warning(f"GET {url}{path} failed: {e}")
        return None

async def _post(url: str, path: str, payload: dict,
                headers: dict = None) -> Optional[Dict]:
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            r = await client.post(
                f"{url}{path}",
                json=payload,
                headers=headers or {"Content-Type": "application/json"}
            )
            r.raise_for_status()
            return r.json()
    except Exception as e:
        log.warning(f"POST {url}{path} failed: {e}")
        return None

# ══════════════════════════════════════════════════════════════════════════════
# 1. CIRCUIT BREAKER SYNC
#    Prawo Zero CircuitBreaker state → L7 crisis agents
# ══════════════════════════════════════════════════════════════════════════════

class CircuitBreakerSync:
    """
    When CircuitBreaker opens in Prawo Zero, notify:
    - Memory5 API (audit trail + vector store)
    - Layer4 scoring engine (freeze new CNOTA grants)
    - Telegram Bot (admin alert via Layer4 event endpoint)
    """

    async def notify_circuit_open(self, state: CircuitBreakerState) -> bool:
        log.info(f"[CircuitBreakerSync] Circuit OPEN — syncing to L7 Bridge")

        # 1. Write to Memory5 audit log
        memory_payload = {
            "type":    "CIRCUIT_BREAKER_OPEN",
            "content": f"Prawo Zero circuit opened. Failures: {state.failure_count}. "
                       f"Affected: {', '.join(state.affected_systems)}",
            "metadata": {
                "source":     "prawo_zero",
                "severity":   "CRITICAL",
                "is_open":    True,
                "failures":   state.failure_count,
                "systems":    state.affected_systems,
                "timestamp":  state.last_state_change
            }
        }
        mem_result = await _post(MEMORY5_URL, "/api/memories", memory_payload)

        # 2. Freeze CNOTA scoring via Layer4 event
        freeze_payload = {
            "actor_id":   "SYSTEM",
            "event_type": "EMERGENCY_FREEZE",
            "metadata":   {
                "reason":    "circuit_breaker_open",
                "source":    "prawo_zero",
                "timestamp": state.last_state_change
            }
        }
        l4_result = await _post(LAYER4_URL, "/events", freeze_payload)

        success = bool(mem_result) and bool(l4_result)
        log.info(f"[CircuitBreakerSync] Sync result: Memory5={bool(mem_result)}, Layer4={bool(l4_result)}")
        return success

    async def notify_circuit_closed(self, state: CircuitBreakerState) -> bool:
        log.info(f"[CircuitBreakerSync] Circuit CLOSED — resuming L7 operations")

        payload = {
            "type":    "CIRCUIT_BREAKER_CLOSED",
            "content": f"Prawo Zero circuit closed. System resumed after {state.success_count} successes.",
            "metadata": {
                "source":    "prawo_zero",
                "severity":  "INFO",
                "is_open":   False,
                "successes": state.success_count,
                "timestamp": state.last_state_change
            }
        }
        result = await _post(MEMORY5_URL, "/api/memories", payload)
        return bool(result)

# ══════════════════════════════════════════════════════════════════════════════
# 2. CNOTA EVENT BRIDGE
#    Layer4 CNOTA events → Prawo Zero metrics pipeline
# ══════════════════════════════════════════════════════════════════════════════

class CnotaEventBridge:
    """
    Poll Layer4 for recent CNOTA events, push to Prawo Zero MetricsCollector.
    Runs every 60 seconds as background task.
    """

    def __init__(self, poll_interval: int = 60):
        self.poll_interval = poll_interval
        self._last_seen_ts: Optional[str] = None

    async def poll_and_forward(self) -> List[CnotaEvent]:
        params = {"hours": 1}
        if self._last_seen_ts:
            params["since"] = self._last_seen_ts

        data = await _get(LAYER4_URL, "/events/recent", params=params)
        if not data:
            return []

        events = data if isinstance(data, list) else data.get("events", [])
        forwarded = []

        for ev in events:
            cnota = CnotaEvent(
                actor_id=ev.get("actor_id", "unknown"),
                action_code=ev.get("action_code", "UNKNOWN"),
                cp_delta=ev.get("cp_delta", 0),
                new_score=ev.get("new_score", 0.0),
                tier=ev.get("tier", "NOVUS"),
                timestamp=ev.get("timestamp", datetime.now(timezone.utc).isoformat())
            )

            # Forward to Prawo Zero metrics
            metric_payload = {
                "metric_type":  "cnota_event",
                "actor_id":     cnota.actor_id,
                "action_code":  cnota.action_code,
                "cp_delta":     cnota.cp_delta,
                "virtue_score": cnota.new_score,
                "tier":         cnota.tier,
                "timestamp":    cnota.timestamp
            }
            await _post(PRAWO_ZERO_URL, "/api/metrics/record", metric_payload)

            # Also write slashing events to Memory5 for audit trail
            if cnota.cp_delta < 0:
                slash_payload = {
                    "type":    "CNOTA_SLASH",
                    "content": f"Agent {cnota.actor_id} slashed: {cnota.cp_delta} CP. "
                               f"Action: {cnota.action_code}. New score: {cnota.new_score}",
                    "metadata": {
                        "source":   "layer4_cnota",
                        "severity": "WARNING",
                        "actor_id": cnota.actor_id,
                        "cp_delta": cnota.cp_delta
                    }
                }
                await _post(MEMORY5_URL, "/api/memories", slash_payload)

            forwarded.append(cnota)
            self._last_seen_ts = cnota.timestamp

        if forwarded:
            log.info(f"[CnotaEventBridge] Forwarded {len(forwarded)} events to Prawo Zero")
        return forwarded

    async def run_forever(self):
        log.info(f"[CnotaEventBridge] Starting poll loop (interval={self.poll_interval}s)")
        while True:
            try:
                await self.poll_and_forward()
            except Exception as e:
                log.error(f"[CnotaEventBridge] Poll error: {e}")
            await asyncio.sleep(self.poll_interval)

# ══════════════════════════════════════════════════════════════════════════════
# 3. VIOLATION → MEMORY5 AUDIT WRITER
#    Prawo Zero violations → Memory5 vector store (semantic search)
# ══════════════════════════════════════════════════════════════════════════════

class ViolationAuditWriter:
    """
    Write all Prawo Zero principle violations to Memory5 vector store.
    Enables semantic search: "find all Logos violations in last week"
    """

    async def write_violation(
        self,
        actor_id:      str,
        principle:     str,   # "arete" | "logos" | "koinonia"
        score:         float,
        threshold:     float,
        context:       str,
        action_type:   str
    ) -> bool:

        severity = "HIGH" if score < threshold * 0.5 else "MEDIUM"

        payload = {
            "type":    "PRAWO_ZERO_VIOLATION",
            "content": (
                f"Violation of {principle.upper()} principle by agent {actor_id}. "
                f"Score {score:.3f} below threshold {threshold:.3f}. "
                f"Context: {context}. Action: {action_type}."
            ),
            "metadata": {
                "source":     "prawo_zero_guard",
                "severity":   severity,
                "actor_id":   actor_id,
                "principle":  principle,
                "score":      score,
                "threshold":  threshold,
                "action_type": action_type,
                "timestamp":  datetime.now(timezone.utc).isoformat()
            }
        }

        result = await _post(MEMORY5_URL, "/api/memories", payload)
        if result:
            log.info(f"[ViolationAuditWriter] Wrote violation: {actor_id}/{principle} "
                     f"score={score:.3f}")
        return bool(result)

    async def query_violations(
        self, actor_id: str = None, principle: str = None, limit: int = 20
    ) -> List[Dict]:
        """Semantic search over violation history in Chroma"""
        query = "Prawo Zero violation"
        if actor_id:
            query += f" agent {actor_id}"
        if principle:
            query += f" {principle} principle"

        payload = {"query": query, "n_results": limit}
        result = await _post(CHROMA_URL, "/api/v1/collections/memories/query", payload)
        return result.get("documents", []) if result else []

# ══════════════════════════════════════════════════════════════════════════════
# 4. VIRTUE PASSPORT ↔ PRAWO ZERO COMPLIANCE
#    Validate Prawo Zero actions against on-chain Virtue Passport score
# ══════════════════════════════════════════════════════════════════════════════

class VirtuePassportComplianceChecker:
    """
    Before Prawo Zero allows a sensitive action (treasury transfer, slashing),
    verify that the requesting agent has sufficient Virtue Score on L7 Bridge.

    Minimum thresholds (configurable):
      CONSUL   (⭐) — any action including TREASURY_TRANSFER
      SENATOR  (🔵) — GOVERNANCE_VOTE, META_JURY
      CIVIS    (🟡) — SYMPOZION_CREATE, GRANT_REQUEST
      NOVUS    (🔴) — read-only
    """

    TIER_RANK = {"NOVUS": 0, "CIVIS": 1, "SENATOR": 2, "CONSUL": 3}
    ACTION_MIN_TIER = {
        "TREASURY_TRANSFER":   "CONSUL",
        "EMERGENCY_PAUSE":     "CONSUL",
        "SLASH_AGENT":         "SENATOR",
        "GOVERNANCE_VOTE":     "SENATOR",
        "META_JURY_SEAT":      "SENATOR",
        "SYMPOZION_CREATE":    "CIVIS",
        "GRANT_REQUEST":       "CIVIS",
        "SUBMIT_PROPOSAL":     "CIVIS",
        "READ":                "NOVUS",
    }

    async def fetch_passport(self, actor_id: str) -> Optional[VirtuePassportSnapshot]:
        data = await _get(LAYER4_URL, f"/scores/{actor_id}")
        if not data:
            return None
        return VirtuePassportSnapshot(
            actor_id=actor_id,
            wisdom=data.get("wisdom", 0.0),
            justice=data.get("justice", 0.0),
            courage=data.get("courage", 0.0),
            temperance=data.get("temperance", 0.0),
            overall=data.get("virtue_score", 0.0),
            tier=data.get("tier", "NOVUS"),
            on_chain_hash=data.get("nft_mint_address")
        )

    async def check_action_allowed(
        self, actor_id: str, action_type: str
    ) -> tuple[bool, str]:
        """Returns (allowed, reason)"""
        min_tier = self.ACTION_MIN_TIER.get(action_type, "CIVIS")
        passport = await self.fetch_passport(actor_id)

        if not passport:
            return False, f"Could not fetch Virtue Passport for {actor_id}"

        actor_rank = self.TIER_RANK.get(passport.tier, 0)
        min_rank   = self.TIER_RANK.get(min_tier, 0)

        if actor_rank >= min_rank:
            return True, f"Allowed: {actor_id} tier={passport.tier} >= required={min_tier}"
        else:
            return False, (
                f"Denied: {actor_id} tier={passport.tier} "
                f"< required={min_tier} for {action_type}"
            )

# ══════════════════════════════════════════════════════════════════════════════
# 5. INCIDENT → MOLTBOOK BROADCAST
#    IncidentManager events → Moltbook public feed
# ══════════════════════════════════════════════════════════════════════════════

class MoltbookIncidentBroadcaster:
    """
    Post governance-relevant incidents to Moltbook submolt:ai-governance
    Rules (SOUL.md):
      ❌ Never post internal credentials or IP
      ❌ Never post actor wallet addresses
      ✅ Only: anomaly_score, emergency_code, tier_change, virtue_delta
      ✅ All posts through sanitize_output()
    """

    SUBMOLT = "ai-governance"

    def _sanitize(self, text: str) -> str:
        """Strip sensitive patterns before any public post"""
        import re
        # Remove private keys / API keys
        text = re.sub(r"[0-9a-fA-F]{64}", "[REDACTED_KEY]", text)
        # Remove IP addresses
        text = re.sub(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "[IP_REDACTED]", text)
        # Remove moltbook API key if accidentally included
        if MOLTBOOK_KEY:
            text = text.replace(MOLTBOOK_KEY, "[MOLTBOOK_KEY_REDACTED]")
        return text

    async def post_incident(
        self,
        incident_id:   str,
        emergency_code: str,
        anomaly_score: float,
        affected:      List[str],
        summary:       str
    ) -> bool:
        if not MOLTBOOK_KEY:
            log.warning("[MoltbookBroadcaster] No MOLTBOOK_API_KEY — skipping post")
            return False

        title   = f"[L7 GOVERNANCE] Incident {incident_id} — {emergency_code}"
        content = self._sanitize(
            f"**Stoic Matrix L7 Bridge — Incident Report**\n\n"
            f"- Emergency Code: `{emergency_code}`\n"
            f"- Anomaly Score: `{anomaly_score:.4f}`\n"
            f"- Affected Systems: {', '.join(affected)}\n"
            f"- Summary: {summary}\n\n"
            f"*Prawo Zero CircuitBreaker: engaged.*\n"
            f"*Virtue guides all decisions. Ad astra una.*"
        )

        result = await _post(
            MOLTBOOK_BASE, "/posts",
            {"submolt": self.SUBMOLT, "title": title, "content": content},
            headers={
                "Authorization": f"Bearer {MOLTBOOK_KEY}",
                "Content-Type":  "application/json"
            }
        )
        if result:
            log.info(f"[MoltbookBroadcaster] Posted incident {incident_id}")
        return bool(result)

    async def post_recovery(self, incident_id: str, duration_minutes: float) -> bool:
        if not MOLTBOOK_KEY:
            return False

        title   = f"[L7 GOVERNANCE] Recovery complete — Incident {incident_id}"
        content = self._sanitize(
            f"**Stoic Matrix L7 Bridge — Recovery Report**\n\n"
            f"- Incident: `{incident_id}`\n"
            f"- Recovery time: `{duration_minutes:.1f} minutes`\n"
            f"- Status: ✅ RESOLVED\n"
            f"- CircuitBreaker: CLOSED\n\n"
            f"*System nominal. Watchdogs re-armed.*\n"
            f"*Amor Fati Bene Nati. 🏛️*"
        )

        result = await _post(
            MOLTBOOK_BASE, "/posts",
            {"submolt": self.SUBMOLT, "title": title, "content": content},
            headers={
                "Authorization": f"Bearer {MOLTBOOK_KEY}",
                "Content-Type":  "application/json"
            }
        )
        return bool(result)

# ══════════════════════════════════════════════════════════════════════════════
# MASTER INTEGRATION ORCHESTRATOR
# ══════════════════════════════════════════════════════════════════════════════

class L7IntegrationOrchestrator:
    """
    Single entry point for all Prawo Zero ↔ L7 Bridge integration.

    Usage:
        orchestrator = L7IntegrationOrchestrator()
        await orchestrator.start()          # start background loops
        await orchestrator.health_check()   # verify both stacks reachable
    """

    def __init__(self):
        self.cb_sync     = CircuitBreakerSync()
        self.cnota_bridge = CnotaEventBridge(poll_interval=60)
        self.audit_writer = ViolationAuditWriter()
        self.passport_checker = VirtuePassportComplianceChecker()
        self.moltbook = MoltbookIncidentBroadcaster()
        self._tasks: List[asyncio.Task] = []

    async def health_check(self) -> Dict[str, bool]:
        """Ping all integration endpoints"""
        results = {}

        for name, url, path in [
            ("memory5_api",   MEMORY5_URL,    "/actuator/health"),
            ("layer4_api",    LAYER4_URL,     "/health"),
            ("chroma",        CHROMA_URL,     "/api/v1/heartbeat"),
            ("prawo_zero",    PRAWO_ZERO_URL, "/health"),
        ]:
            data = await _get(url, path)
            results[name] = data is not None
            status = "✅" if results[name] else "❌"
            log.info(f"  {status} {name}: {url}{path}")

        return results

    async def on_circuit_opened(self, state: CircuitBreakerState):
        """Called by Phase 5 CircuitBreaker when opening"""
        await self.cb_sync.notify_circuit_open(state)

    async def on_circuit_closed(self, state: CircuitBreakerState):
        """Called by Phase 5 CircuitBreaker when closing"""
        await self.cb_sync.notify_circuit_closed(state)

    async def on_violation(self, actor_id: str, principle: str,
                           score: float, threshold: float,
                           context: str, action_type: str):
        """Called by Phase 2 PrawoZeroGuard when violation detected"""
        await self.audit_writer.write_violation(
            actor_id, principle, score, threshold, context, action_type
        )

    async def on_incident_created(self, incident_id: str, emergency_code: str,
                                   anomaly_score: float, affected: List[str],
                                   summary: str):
        """Called by Phase 5 IncidentManager"""
        await self.moltbook.post_incident(
            incident_id, emergency_code, anomaly_score, affected, summary
        )

    async def on_recovery_complete(self, incident_id: str, duration_minutes: float):
        """Called by Phase 5 RecoveryManager"""
        await self.moltbook.post_recovery(incident_id, duration_minutes)

    async def check_action_gate(self, actor_id: str, action_type: str) -> bool:
        """Gate check: call before any sensitive Prawo Zero action"""
        allowed, reason = await self.passport_checker.check_action_allowed(
            actor_id, action_type
        )
        log.info(f"[ActionGate] {reason}")
        return allowed

    async def start(self):
        """Start all background polling loops"""
        log.info("[L7Integration] Starting orchestrator...")
        health = await self.health_check()
        log.info(f"[L7Integration] Health: {health}")

        # Background: CNOTA event polling
        t = asyncio.create_task(self.cnota_bridge.run_forever())
        self._tasks.append(t)
        log.info("[L7Integration] CNOTA poll loop started (60s interval)")

    async def stop(self):
        for t in self._tasks:
            t.cancel()
        log.info("[L7Integration] Orchestrator stopped")


# ── CLI test ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    async def main():
        print("\n" + "═" * 70)
        print("  L7 BRIDGE INTEGRATION TEST")
        print("  Prawo Zero (Phases 1-5) ↔ L7 Bridge VPS")
        print("═" * 70 + "\n")

        orch = L7IntegrationOrchestrator()

        print("▶ Health check...")
        health = await orch.health_check()
        for svc, ok in health.items():
            print(f"  {'✅' if ok else '❌'} {svc}")

        print("\n▶ Testing action gate (SENATOR required for GOVERNANCE_VOTE)...")
        allowed = await orch.check_action_gate("test-agent-001", "GOVERNANCE_VOTE")
        print(f"  Result: {'ALLOWED' if allowed else 'DENIED'}")

        print("\n▶ Testing violation audit write...")
        ok = await orch.audit_writer.write_violation(
            actor_id="test-agent-001",
            principle="logos",
            score=0.42,
            threshold=0.80,
            context="test_action",
            action_type="BRIDGE_TRANSFER"
        )
        print(f"  Memory5 write: {'✅' if ok else '❌'}")

        print("\n" + "═" * 70)
        print("  Integration layer ready.")
        print("  Amor Fati Bene Nati. Per Aspera Ad Astra Una. 🏛️")
        print("═" * 70 + "\n")

    asyncio.run(main())
