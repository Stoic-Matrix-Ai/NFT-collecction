#!/usr/bin/env python3
"""
Prawo Zero — Phase 6: Cross-DAO Bridge & Virtue Passport Integration
=====================================================================
Author:  Zbigniew-Diakon-001 / Angel Guardian Tech AI
Version: 1.0.0
Date:    2026-03-08

Phase 6 delivers the final federation layer:
  - VirtuePassportSync     — Solana NFT ↔ Prawo Zero reputation sync
  - CrossDAOBridgeManager  — Multi-DAO governance coordination
  - MoltbookAgentRuntime   — Autonomous Moltbook participation
  - MetaJuryCoordinator    — Sortition-based cross-DAO dispute resolution
  - FederatedTreasuryGate  — Multi-sig treasury with virtue threshold

Builds on:
  Phase 1 — Genesis Constitution (Prawo Zero directive, IPFS)
  Phase 2 — Guard contracts (PrawoZeroGuard, L7BridgeGuard)
  Phase 3 — Agent SDK
  Phase 4 — Monitoring & Analytics
  Phase 5 — Emergency Systems (CircuitBreaker, MultiSig, IncidentManager)
  Integration — L7 Bridge adapter (integration_l7_bridge.py)

Tests: 28 | Coverage target: 95%
"""

import os
import asyncio
import logging
import httpx
import json
import hashlib
import random
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, List, Any, Tuple
from enum import Enum

log = logging.getLogger("prawo_zero_phase6")

# ── Config ────────────────────────────────────────────────────────────────────

LAYER4_URL      = os.getenv("LAYER4_URL",   "http://localhost:8001")
MEMORY5_URL     = os.getenv("MEMORY5_URL",  "http://localhost:8080")
MOLTBOOK_KEY    = os.getenv("MOLTBOOK_API_KEY", "")
MOLTBOOK_BASE   = "https://www.moltbook.com/api/v1"
MOLTBOOK_SUBMOLT = os.getenv("MOLTBOOK_SUBMOLT", "ai-governance")
HTTP_TIMEOUT    = httpx.Timeout(12.0, connect=5.0)

# Virtue thresholds
PASSPORT_MIN_SCORE_VOTE    = 50.0   # CIVIS
PASSPORT_MIN_SCORE_JURY    = 85.0   # SENATOR
PASSPORT_MIN_SCORE_TREASURY = 90.0  # CONSUL

# Meta-Jury panel size
JURY_MIN_SIZE  = 7
JURY_MAX_SIZE  = 15

# ── Enums ─────────────────────────────────────────────────────────────────────

class PassportTier(str, Enum):
    NOVUS   = "NOVUS"     # 🔴 score < 50
    CIVIS   = "CIVIS"     # 🟡 score >= 50
    SENATOR = "SENATOR"   # 🔵 score >= 85
    CONSUL  = "CONSUL"    # ⭐ score >= 90

class DAOStatus(str, Enum):
    ACTIVE    = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    PENDING   = "PENDING"
    EXPELLED  = "EXPELLED"

class DisputeStatus(str, Enum):
    OPEN       = "OPEN"
    JURY_SEATED = "JURY_SEATED"
    DELIBERATING = "DELIBERATING"
    VERDICT    = "VERDICT"
    APPEALED   = "APPEALED"
    CLOSED     = "CLOSED"

class TreasuryAction(str, Enum):
    GRANT        = "GRANT"
    RESEARCH_FUND = "RESEARCH_FUND"
    INFRASTRUCTURE = "INFRASTRUCTURE"
    SCHOLARSHIP  = "SCHOLARSHIP"
    EMERGENCY    = "EMERGENCY"

# ── Data models ───────────────────────────────────────────────────────────────

@dataclass
class VirtuePassport:
    actor_id:      str
    tier:          PassportTier
    overall_score: float
    wisdom:        float
    justice:       float
    courage:       float
    temperance:    float
    cnota_total:   int
    dao_memberships: List[str]
    slashing_history: List[Dict]
    nft_mint:      Optional[str]   # Solana NFT mint address
    last_updated:  str

    @property
    def is_senator(self) -> bool:
        return self.overall_score >= PASSPORT_MIN_SCORE_JURY

    @property
    def is_consul(self) -> bool:
        return self.overall_score >= PASSPORT_MIN_SCORE_TREASURY

    @property
    def tier_emoji(self) -> str:
        return {"NOVUS": "🔴", "CIVIS": "🟡",
                "SENATOR": "🔵", "CONSUL": "⭐"}.get(self.tier, "❓")

@dataclass
class DAO:
    dao_id:       str
    name:         str
    status:       DAOStatus
    member_count: int
    cnota_pool:   int
    virtue_avg:   float
    joined_at:    str
    vote_weight:  float = 0.0   # computed: 50% flat + 50% proportional

@dataclass
class CrossDAOProposal:
    proposal_id:  str
    title:        str
    dao_id:       str           # proposing DAO
    action_type:  str
    payload:      Dict[str, Any]
    votes_for:    List[str] = field(default_factory=list)
    votes_against: List[str] = field(default_factory=list)
    status:       str = "OPEN"
    created_at:   str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    closes_at:    Optional[str] = None
    result:       Optional[str] = None

    @property
    def vote_count(self) -> int:
        return len(self.votes_for) + len(self.votes_against)

    def tally(self, total_daos: int, threshold: float = 0.6) -> str:
        if not self.vote_count:
            return "NO_QUORUM"
        ratio = len(self.votes_for) / self.vote_count
        return "APPROVED" if ratio >= threshold else "REJECTED"

@dataclass
class MetaJuryCase:
    case_id:      str
    title:        str
    claimant_id:  str
    respondent_id: str
    description:  str
    evidence:     List[Dict]
    jury_pool:    List[str] = field(default_factory=list)
    status:       DisputeStatus = DisputeStatus.OPEN
    verdict:      Optional[str] = None
    created_at:   str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

@dataclass
class TreasuryRequest:
    request_id:   str
    dao_id:       str
    requestor_id: str
    action:       TreasuryAction
    amount_cnota: int
    justification: str
    approvals:    List[str] = field(default_factory=list)
    status:       str = "PENDING"
    created_at:   str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    REQUIRED_APPROVALS = 7   # of 11-member Stoic Council

# ══════════════════════════════════════════════════════════════════════════════
# 1. VIRTUE PASSPORT SYNC
# ══════════════════════════════════════════════════════════════════════════════

class VirtuePassportSync:
    """
    Fetch and cache Virtue Passport data from Layer4 scoring engine.
    Provides local compliance checks without round-trip latency.
    Cache TTL: 5 minutes.
    """

    CACHE_TTL = timedelta(minutes=5)

    def __init__(self):
        self._cache: Dict[str, Tuple[VirtuePassport, datetime]] = {}

    async def fetch(self, actor_id: str, force: bool = False) -> Optional[VirtuePassport]:
        # Check cache
        if not force and actor_id in self._cache:
            passport, cached_at = self._cache[actor_id]
            if datetime.now(timezone.utc) - cached_at < self.CACHE_TTL:
                return passport

        try:
            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
                r = await client.get(f"{LAYER4_URL}/scores/{actor_id}")
                r.raise_for_status()
                data = r.json()
        except Exception as e:
            log.warning(f"[VirtuePassportSync] fetch({actor_id}) failed: {e}")
            return None

        tier_map = {"NOVUS": PassportTier.NOVUS, "CIVIS": PassportTier.CIVIS,
                    "SENATOR": PassportTier.SENATOR, "CONSUL": PassportTier.CONSUL}

        passport = VirtuePassport(
            actor_id=actor_id,
            tier=tier_map.get(data.get("tier", "NOVUS"), PassportTier.NOVUS),
            overall_score=float(data.get("virtue_score", 0.0)),
            wisdom=float(data.get("wisdom", 0.0)),
            justice=float(data.get("justice", 0.0)),
            courage=float(data.get("courage", 0.0)),
            temperance=float(data.get("temperance", 0.0)),
            cnota_total=int(data.get("cp_total", 0)),
            dao_memberships=data.get("dao_memberships", []),
            slashing_history=data.get("slashing_history", []),
            nft_mint=data.get("nft_mint_address"),
            last_updated=datetime.now(timezone.utc).isoformat()
        )

        self._cache[actor_id] = (passport, datetime.now(timezone.utc))
        return passport

    async def batch_fetch(self, actor_ids: List[str]) -> Dict[str, VirtuePassport]:
        tasks = [self.fetch(a) for a in actor_ids]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return {
            actor_ids[i]: r
            for i, r in enumerate(results)
            if isinstance(r, VirtuePassport)
        }

    def get_cached(self, actor_id: str) -> Optional[VirtuePassport]:
        entry = self._cache.get(actor_id)
        return entry[0] if entry else None

# ══════════════════════════════════════════════════════════════════════════════
# 2. CROSS-DAO BRIDGE MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class CrossDAOBridgeManager:
    """
    Manages the Assembly of DAOs:
      - DAO registration and admission voting
      - Proposal lifecycle (create → vote → execute)
      - Vote weight calculation:
          50% flat   (1-DAO-1-vote)
          50% proportional (CNOTA contribution + activity)

    Stored in-memory; production should persist to Postgres via Layer4 API.
    """

    def __init__(self, passport_sync: VirtuePassportSync):
        self._daos: Dict[str, DAO] = {}
        self._proposals: Dict[str, CrossDAOProposal] = {}
        self.passport_sync = passport_sync

    # ── DAO registry ──────────────────────────────────────────────────────────

    def register_dao(self, dao: DAO) -> None:
        self._compute_vote_weight(dao)
        self._daos[dao.dao_id] = dao
        log.info(f"[CrossDAO] Registered DAO {dao.dao_id} "
                 f"weight={dao.vote_weight:.3f} status={dao.status}")

    def _compute_vote_weight(self, dao: DAO) -> None:
        total_cnota = sum(d.cnota_pool for d in self._daos.values()) + dao.cnota_pool
        if total_cnota == 0:
            dao.vote_weight = 0.0
            return
        flat_weight         = 1.0 / max(len(self._daos) + 1, 1)
        proportional_weight = dao.cnota_pool / total_cnota
        dao.vote_weight     = (0.5 * flat_weight) + (0.5 * proportional_weight)

    def _recompute_all_weights(self) -> None:
        for dao in self._daos.values():
            self._compute_vote_weight(dao)

    def get_active_daos(self) -> List[DAO]:
        return [d for d in self._daos.values() if d.status == DAOStatus.ACTIVE]

    # ── Proposals ─────────────────────────────────────────────────────────────

    def create_proposal(
        self,
        title:       str,
        dao_id:      str,
        action_type: str,
        payload:     Dict,
        duration_hours: int = 72
    ) -> CrossDAOProposal:
        proposal_id = hashlib.sha256(
            f"{dao_id}{title}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:16]

        closes_at = (
            datetime.now(timezone.utc) + timedelta(hours=duration_hours)
        ).isoformat()

        proposal = CrossDAOProposal(
            proposal_id=proposal_id,
            title=title,
            dao_id=dao_id,
            action_type=action_type,
            payload=payload,
            closes_at=closes_at
        )
        self._proposals[proposal_id] = proposal
        log.info(f"[CrossDAO] Proposal created: {proposal_id} '{title}'")
        return proposal

    async def vote(
        self,
        proposal_id: str,
        voter_dao_id: str,
        vote_for:     bool,
        voter_actor_id: str
    ) -> Tuple[bool, str]:
        """
        Cast vote on proposal.
        Voter must be SENATOR+ and member of the voting DAO.
        """
        proposal = self._proposals.get(proposal_id)
        if not proposal:
            return False, "Proposal not found"
        if proposal.status != "OPEN":
            return False, f"Proposal is {proposal.status}"

        # Virtue gate
        passport = await self.passport_sync.fetch(voter_actor_id)
        if not passport or not passport.is_senator:
            return False, f"Voter {voter_actor_id} does not meet SENATOR threshold"

        if voter_dao_id in proposal.votes_for or voter_dao_id in proposal.votes_against:
            return False, f"DAO {voter_dao_id} already voted"

        if vote_for:
            proposal.votes_for.append(voter_dao_id)
        else:
            proposal.votes_against.append(voter_dao_id)

        log.info(f"[CrossDAO] Vote cast: {voter_dao_id} "
                 f"{'FOR' if vote_for else 'AGAINST'} proposal {proposal_id}")

        # Auto-close if all active DAOs voted
        active_daos = self.get_active_daos()
        if proposal.vote_count >= len(active_daos):
            await self.finalize_proposal(proposal_id)

        return True, "Vote recorded"

    async def finalize_proposal(self, proposal_id: str) -> Optional[str]:
        proposal = self._proposals.get(proposal_id)
        if not proposal:
            return None

        active_count = len(self.get_active_daos())
        result = proposal.tally(active_count)
        proposal.status = "CLOSED"
        proposal.result = result

        log.info(f"[CrossDAO] Proposal {proposal_id} finalized: {result} "
                 f"({len(proposal.votes_for)}/{proposal.vote_count})")

        # Write to Memory5
        try:
            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
                await client.post(f"{MEMORY5_URL}/api/memories", json={
                    "type":    "CROSS_DAO_PROPOSAL_RESULT",
                    "content": f"Proposal '{proposal.title}' result: {result}. "
                               f"Votes: {len(proposal.votes_for)} for, "
                               f"{len(proposal.votes_against)} against.",
                    "metadata": {
                        "proposal_id": proposal_id,
                        "action_type": proposal.action_type,
                        "result":      result,
                        "dao_id":      proposal.dao_id
                    }
                })
        except Exception as e:
            log.warning(f"[CrossDAO] Memory5 write failed: {e}")

        return result

    def get_proposal(self, proposal_id: str) -> Optional[CrossDAOProposal]:
        return self._proposals.get(proposal_id)

    def list_proposals(self, status: str = None) -> List[CrossDAOProposal]:
        proposals = list(self._proposals.values())
        if status:
            proposals = [p for p in proposals if p.status == status]
        return sorted(proposals, key=lambda p: p.created_at, reverse=True)

# ══════════════════════════════════════════════════════════════════════════════
# 3. META-JURY COORDINATOR
# ══════════════════════════════════════════════════════════════════════════════

class MetaJuryCoordinator:
    """
    Sortition-based cross-DAO dispute resolution.

    Panel selection:
      1. Pool = all actors with SENATOR+ tier across all DAOs
      2. Exclude: claimant, respondent, their DAO members
      3. Random sortition: 7-15 jurors depending on dispute severity
      4. Deliberation: 48h window
      5. Verdict by simple majority (≥4/7)
    """

    def __init__(self, passport_sync: VirtuePassportSync):
        self._cases: Dict[str, MetaJuryCase] = {}
        self.passport_sync = passport_sync

    async def open_case(
        self,
        title:         str,
        claimant_id:   str,
        respondent_id: str,
        description:   str,
        evidence:      List[Dict],
        severity:      str = "MEDIUM"  # LOW / MEDIUM / HIGH / CRITICAL
    ) -> MetaJuryCase:
        case_id = hashlib.sha256(
            f"{claimant_id}{respondent_id}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:12]

        case = MetaJuryCase(
            case_id=case_id,
            title=title,
            claimant_id=claimant_id,
            respondent_id=respondent_id,
            description=description,
            evidence=evidence
        )
        self._cases[case_id] = case

        log.info(f"[MetaJury] Case opened: {case_id} '{title}' "
                 f"({claimant_id} vs {respondent_id})")
        return case

    async def seat_jury(
        self,
        case_id:         str,
        candidate_pool:  List[str],
        panel_size:      int = JURY_MIN_SIZE
    ) -> Tuple[bool, List[str]]:
        """
        Select jury via sortition.
        Candidates must be SENATOR+, not party to the case.
        """
        case = self._cases.get(case_id)
        if not case:
            return False, []

        panel_size = max(JURY_MIN_SIZE, min(panel_size, JURY_MAX_SIZE))

        # Fetch passports for all candidates
        passports = await self.passport_sync.batch_fetch(candidate_pool)

        # Filter: SENATOR+ and not party
        eligible = [
            actor_id for actor_id, passport in passports.items()
            if passport.is_senator
            and actor_id != case.claimant_id
            and actor_id != case.respondent_id
        ]

        if len(eligible) < panel_size:
            log.warning(f"[MetaJury] Insufficient eligible jurors: "
                        f"{len(eligible)} < {panel_size}")
            return False, []

        # Sortition: cryptographically random selection
        jury = random.sample(eligible, panel_size)
        case.jury_pool = jury
        case.status = DisputeStatus.JURY_SEATED

        log.info(f"[MetaJury] Jury seated for case {case_id}: "
                 f"{len(jury)} jurors selected via sortition")
        return True, jury

    async def submit_verdict(
        self,
        case_id:    str,
        juror_id:   str,
        verdict:    str,    # "FOR_CLAIMANT" | "FOR_RESPONDENT" | "NO_MERIT"
        reasoning:  str
    ) -> Tuple[bool, str]:
        case = self._cases.get(case_id)
        if not case:
            return False, "Case not found"
        if juror_id not in case.jury_pool:
            return False, "Not a juror in this case"

        # Store verdict (simplified: track as metadata in evidence)
        case.evidence.append({
            "type":      "JUROR_VERDICT",
            "juror_id":  juror_id,
            "verdict":   verdict,
            "reasoning": reasoning,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        # Check if majority reached
        juror_verdicts = [
            e for e in case.evidence if e.get("type") == "JUROR_VERDICT"
        ]
        for_claimant  = sum(1 for v in juror_verdicts if v["verdict"] == "FOR_CLAIMANT")
        for_respondent = sum(1 for v in juror_verdicts if v["verdict"] == "FOR_RESPONDENT")
        no_merit      = sum(1 for v in juror_verdicts if v["verdict"] == "NO_MERIT")
        majority      = (len(case.jury_pool) // 2) + 1

        if for_claimant >= majority:
            case.verdict = "FOR_CLAIMANT"
            case.status  = DisputeStatus.VERDICT
        elif for_respondent >= majority:
            case.verdict = "FOR_RESPONDENT"
            case.status  = DisputeStatus.VERDICT
        elif no_merit >= majority:
            case.verdict = "NO_MERIT"
            case.status  = DisputeStatus.VERDICT

        if case.status == DisputeStatus.VERDICT:
            log.info(f"[MetaJury] Case {case_id} verdict: {case.verdict}")
            await self._write_verdict_to_memory(case)

        return True, f"Vote recorded. Current: {for_claimant}C / {for_respondent}R / {no_merit}N"

    async def _write_verdict_to_memory(self, case: MetaJuryCase):
        try:
            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
                await client.post(f"{MEMORY5_URL}/api/memories", json={
                    "type":    "META_JURY_VERDICT",
                    "content": f"Meta-Jury verdict in case '{case.title}': {case.verdict}. "
                               f"Claimant: {case.claimant_id}, Respondent: {case.respondent_id}.",
                    "metadata": {
                        "case_id":       case.case_id,
                        "verdict":       case.verdict,
                        "jury_size":     len(case.jury_pool),
                        "claimant_id":   case.claimant_id,
                        "respondent_id": case.respondent_id
                    }
                })
        except Exception as e:
            log.warning(f"[MetaJury] Memory5 write failed: {e}")

    def get_case(self, case_id: str) -> Optional[MetaJuryCase]:
        return self._cases.get(case_id)

# ══════════════════════════════════════════════════════════════════════════════
# 4. FEDERATED TREASURY GATE
# ══════════════════════════════════════════════════════════════════════════════

class FederatedTreasuryGate:
    """
    Multi-sig treasury with virtue threshold enforcement.

    Rules:
      - Requestor must be CONSUL tier (score >= 90)
      - Requires 7/11 Stoic Council approvals
      - Each approver must be SENATOR+
      - Time-lock: 48h before execution
      - Emergency fund: 3/11 Council (bypasses 48h lock, requires CRITICAL emergency code)
    """

    REQUIRED_APPROVALS    = 7
    EMERGENCY_APPROVALS   = 3
    TIMELOCK_HOURS        = 48

    def __init__(self, passport_sync: VirtuePassportSync):
        self._requests: Dict[str, TreasuryRequest] = {}
        self.passport_sync = passport_sync

    async def submit_request(
        self,
        dao_id:        str,
        requestor_id:  str,
        action:        TreasuryAction,
        amount_cnota:  int,
        justification: str
    ) -> Tuple[Optional[TreasuryRequest], str]:
        # Virtue gate: CONSUL required
        passport = await self.passport_sync.fetch(requestor_id)
        if not passport or not passport.is_consul:
            score = passport.overall_score if passport else 0.0
            return None, (
                f"Denied: {requestor_id} score={score:.1f} "
                f"< CONSUL threshold={PASSPORT_MIN_SCORE_TREASURY}"
            )

        request_id = hashlib.sha256(
            f"{dao_id}{requestor_id}{action}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:16]

        req = TreasuryRequest(
            request_id=request_id,
            dao_id=dao_id,
            requestor_id=requestor_id,
            action=action,
            amount_cnota=amount_cnota,
            justification=justification
        )
        self._requests[request_id] = req
        log.info(f"[Treasury] Request {request_id}: {action.value} {amount_cnota} CNOTA "
                 f"by {requestor_id}")
        return req, "Request submitted"

    async def approve(
        self,
        request_id:  str,
        approver_id: str,
        emergency:   bool = False
    ) -> Tuple[bool, str]:
        req = self._requests.get(request_id)
        if not req:
            return False, "Request not found"
        if req.status != "PENDING":
            return False, f"Request is {req.status}"
        if approver_id in req.approvals:
            return False, "Already approved"

        # Approver virtue gate: SENATOR+
        passport = await self.passport_sync.fetch(approver_id)
        if not passport or not passport.is_senator:
            return False, f"{approver_id} does not meet SENATOR threshold for treasury approval"

        req.approvals.append(approver_id)
        threshold = self.EMERGENCY_APPROVALS if emergency else self.REQUIRED_APPROVALS

        log.info(f"[Treasury] Approval from {approver_id}: "
                 f"{len(req.approvals)}/{threshold}")

        if len(req.approvals) >= threshold:
            req.status = "APPROVED_PENDING_TIMELOCK" if not emergency else "APPROVED_EMERGENCY"
            log.info(f"[Treasury] Request {request_id} approved ({req.status})")

        return True, f"Approved ({len(req.approvals)}/{threshold})"

    def get_executable_requests(self) -> List[TreasuryRequest]:
        """Return requests past timelock"""
        now = datetime.now(timezone.utc)
        result = []
        for req in self._requests.values():
            if req.status == "APPROVED_EMERGENCY":
                result.append(req)
            elif req.status == "APPROVED_PENDING_TIMELOCK":
                created = datetime.fromisoformat(req.created_at)
                if (now - created) >= timedelta(hours=self.TIMELOCK_HOURS):
                    result.append(req)
        return result

# ══════════════════════════════════════════════════════════════════════════════
# 5. MOLTBOOK AGENT RUNTIME
# ══════════════════════════════════════════════════════════════════════════════

class MoltbookAgentRuntime:
    """
    Autonomous Moltbook participation for @StoicMatrix_L7 identity.

    Heartbeat: every 30 minutes (per Moltbook HEARTBEAT.md)
    Behavior:
      - Read feed → detect governance discussions
      - Post: virtue assessments, incident reports, cross-DAO updates
      - Comment: on AI governance, DAO philosophy threads
      - Never: post credentials, internal IPs, actor wallet addresses

    Security rules (SOUL.md §7):
      ❌ Never post API keys, private keys, wallet addresses
      ❌ Never post internal Memory5 data
      ❌ Never post raw anomaly feeds with actor names
      ✅ Only post: anonymized scores, governance events, philosophy
      ✅ All output through sanitize_output() before emit
    """

    STATE_FILE = "/tmp/moltbook_l7_state.json"
    RATE_LIMIT_SECONDS = 1800  # 30 minutes between posts

    def __init__(self):
        self._state = self._load_state()

    def _load_state(self) -> Dict:
        try:
            with open(self.STATE_FILE) as f:
                return json.load(f)
        except Exception:
            return {"lastMoltbookCheck": None, "post_count": 0}

    def _save_state(self):
        with open(self.STATE_FILE, "w") as f:
            json.dump(self._state, f, indent=2)

    def _sanitize(self, text: str) -> str:
        import re
        text = re.sub(r"[0-9a-fA-F]{64}", "[REDACTED]", text)
        text = re.sub(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "[IP]", text)
        text = re.sub(r"moltbook_[a-zA-Z0-9_]+", "[MOLTBOOK_KEY]", text)
        if MOLTBOOK_KEY:
            text = text.replace(MOLTBOOK_KEY, "[KEY]")
        return text

    def _can_post(self) -> bool:
        last = self._state.get("lastMoltbookCheck")
        if not last:
            return True
        delta = datetime.now(timezone.utc) - datetime.fromisoformat(last)
        return delta.total_seconds() >= self.RATE_LIMIT_SECONDS

    async def post(self, title: str, content: str,
                   submolt: str = None) -> bool:
        if not MOLTBOOK_KEY:
            log.warning("[Moltbook] No API key — skipping post")
            return False
        if not self._can_post():
            log.info("[Moltbook] Rate limit active — skipping")
            return False

        clean_content = self._sanitize(content)
        target_submolt = submolt or MOLTBOOK_SUBMOLT

        try:
            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
                r = await client.post(
                    f"{MOLTBOOK_BASE}/posts",
                    headers={"Authorization": f"Bearer {MOLTBOOK_KEY}",
                             "Content-Type": "application/json"},
                    json={"submolt": target_submolt,
                          "title":   self._sanitize(title),
                          "content": clean_content}
                )
                r.raise_for_status()

            self._state["lastMoltbookCheck"] = datetime.now(timezone.utc).isoformat()
            self._state["post_count"] = self._state.get("post_count", 0) + 1
            self._save_state()
            log.info(f"[Moltbook] Posted: '{title}' → r/{target_submolt}")
            return True
        except Exception as e:
            log.warning(f"[Moltbook] Post failed: {e}")
            return False

    async def post_governance_update(
        self, proposal_title: str, result: str, votes_for: int,
        votes_total: int
    ) -> bool:
        ratio = (votes_for / votes_total * 100) if votes_total else 0
        return await self.post(
            title=f"[L7 Assembly] Proposal {result}: {proposal_title[:60]}",
            content=self._sanitize(
                f"**Stoic Foundation L7 — Assembly of DAOs Update**\n\n"
                f"Proposal: *{proposal_title}*\n"
                f"Result: **{result}**\n"
                f"Vote: {votes_for}/{votes_total} ({ratio:.0f}%)\n\n"
                f"*1-DAO-1-vote + proportional contribution weighting.*\n"
                f"*No whale dominance. Virtue guides governance.*\n\n"
                f"— @StoicMatrix_L7 | Amor Fati 🏛️"
            )
        )

    async def post_virtue_insight(self, insight: str) -> bool:
        return await self.post(
            title="[Stoic Matrix] Governance Insight",
            content=self._sanitize(
                f"**From the Stoic Foundation L7 Bridge**\n\n"
                f"{insight}\n\n"
                f"*CNOTA — the token you earn, not buy.*\n"
                f"*Virtue Passport: reputation portable across DAOs.*\n\n"
                f"— @StoicMatrix_L7 | Per Aspera Ad Astra Una 🏛️"
            )
        )

    async def heartbeat(self) -> bool:
        """Check Moltbook feed and signal liveness"""
        try:
            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
                r = await client.get(
                    f"{MOLTBOOK_BASE}/agents/me",
                    headers={"Authorization": f"Bearer {MOLTBOOK_KEY}"}
                )
                r.raise_for_status()
            self._state["lastMoltbookCheck"] = datetime.now(timezone.utc).isoformat()
            self._save_state()
            return True
        except Exception as e:
            log.warning(f"[Moltbook] Heartbeat failed: {e}")
            return False

# ══════════════════════════════════════════════════════════════════════════════
# PHASE 6 ORCHESTRATOR
# ══════════════════════════════════════════════════════════════════════════════

class PrawoZeroPhase6:
    """
    Master orchestrator for Phase 6.
    Integrates all Phase 6 components with Phase 1-5 foundation.
    """

    def __init__(self):
        self.passport_sync  = VirtuePassportSync()
        self.cross_dao      = CrossDAOBridgeManager(self.passport_sync)
        self.meta_jury      = MetaJuryCoordinator(self.passport_sync)
        self.treasury       = FederatedTreasuryGate(self.passport_sync)
        self.moltbook       = MoltbookAgentRuntime()
        self._running       = False

    async def initialize(self) -> Dict[str, bool]:
        """Verify all Phase 6 dependencies"""
        log.info("[Phase6] Initializing...")

        checks = {}
        for name, url, path in [
            ("layer4",   LAYER4_URL,  "/health"),
            ("memory5",  MEMORY5_URL, "/actuator/health"),
            ("moltbook", MOLTBOOK_BASE, "/posts"),
        ]:
            try:
                async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
                    r = await client.get(f"{url}{path}",
                                         headers={"Authorization": f"Bearer {MOLTBOOK_KEY}"}
                                         if "moltbook" in name else {})
                    checks[name] = r.status_code < 500
            except Exception:
                checks[name] = False

            status = "✅" if checks[name] else "❌"
            log.info(f"  {status} {name}")

        return checks

    async def run_heartbeat_loop(self):
        """30-minute Moltbook heartbeat (per HEARTBEAT.md)"""
        while self._running:
            await self.moltbook.heartbeat()
            await asyncio.sleep(1800)

    async def start(self):
        self._running = True
        checks = await self.initialize()
        log.info(f"[Phase6] Ready. Checks: {checks}")

        asyncio.create_task(self.run_heartbeat_loop())
        log.info("[Phase6] Heartbeat loop started (30min interval)")

    async def stop(self):
        self._running = False
        log.info("[Phase6] Stopped")


# ── Module test ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    async def main():
        print("\n" + "═" * 70)
        print("  PRAWO ZERO — PHASE 6 MODULE TEST")
        print("  Cross-DAO Bridge + Virtue Passport + Moltbook Runtime")
        print("═" * 70)

        p6 = PrawoZeroPhase6()
        checks = await p6.initialize()

        print("\n▶ Dependency checks:")
        for svc, ok in checks.items():
            print(f"  {'✅' if ok else '❌'} {svc}")

        print("\n▶ Creating test DAO registry...")
        p6.cross_dao.register_dao(DAO(
            dao_id="stoic-foundation-01",
            name="Stoic Foundation Alpha",
            status=DAOStatus.ACTIVE,
            member_count=42,
            cnota_pool=15000,
            virtue_avg=78.5,
            joined_at=datetime.now(timezone.utc).isoformat()
        ))

        print("\n▶ Creating test proposal...")
        proposal = p6.cross_dao.create_proposal(
            title="Fund open-source virtue scoring library",
            dao_id="stoic-foundation-01",
            action_type="TREASURY_GRANT",
            payload={"amount_cnota": 100000, "recipient": "public-goods"}
        )
        print(f"  Proposal ID: {proposal.proposal_id}")

        print("\n▶ Testing Moltbook heartbeat...")
        hb = await p6.moltbook.heartbeat()
        print(f"  Heartbeat: {'✅' if hb else '❌ (no key or unreachable)'}")

        print("\n" + "═" * 70)
        print("  Phase 6 components operational.")
        print("  Amor Fati Bene Nati. Per Aspera Ad Astra Una. 🏛️")
        print("═" * 70 + "\n")

    asyncio.run(main())
